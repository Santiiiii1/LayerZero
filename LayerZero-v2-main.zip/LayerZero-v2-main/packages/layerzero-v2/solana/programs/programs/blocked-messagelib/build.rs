fn main() {
    println!("cargo:rerun-if-env-changed=BLOCKED_MESSAGELIB_ID");
}
