fn main() {
    println!("cargo:rerun-if-env-changed=DVN_ID");
}
