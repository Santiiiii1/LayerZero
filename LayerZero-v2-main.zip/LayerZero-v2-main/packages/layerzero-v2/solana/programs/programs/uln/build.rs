fn main() {
    println!("cargo:rerun-if-env-changed=MESSAGELIB_ID");
}
