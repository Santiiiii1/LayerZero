fn main() {
    println!("cargo:rerun-if-env-changed=SIMPLE_MESSAGELIB_ID");
}
