fn main() {
    println!("cargo:rerun-if-env-changed=OFT_ID");
}
