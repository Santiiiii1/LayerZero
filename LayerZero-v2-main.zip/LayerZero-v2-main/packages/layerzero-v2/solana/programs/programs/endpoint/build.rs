fn main() {
    println!("cargo:rerun-if-env-changed=ENDPOINT_ID");
}
