fn main() {
    println!("cargo:rerun-if-env-changed=PRICEFEED_ID");
}
