export const globalTestResults: { [testName: string]: { [key: string]: boolean } } = {}
