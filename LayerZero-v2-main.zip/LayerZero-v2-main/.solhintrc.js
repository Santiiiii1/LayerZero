module.exports = {
    extends: ['solhint:recommended', require.resolve('@layerzerolabs/solhint-config')],
};
